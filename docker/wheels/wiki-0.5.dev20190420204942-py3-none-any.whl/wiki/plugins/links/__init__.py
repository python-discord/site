default_app_config = 'wiki.plugins.links.apps.LinksConfig'
