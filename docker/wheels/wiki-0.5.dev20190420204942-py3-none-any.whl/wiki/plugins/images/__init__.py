default_app_config = 'wiki.plugins.images.apps.ImagesConfig'
