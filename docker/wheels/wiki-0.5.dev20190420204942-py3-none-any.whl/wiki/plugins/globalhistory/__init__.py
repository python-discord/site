default_app_config = 'wiki.plugins.globalhistory.apps.GlobalHistoryConfig'
