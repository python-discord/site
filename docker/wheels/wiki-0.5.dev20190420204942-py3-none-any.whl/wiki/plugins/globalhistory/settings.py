SLUG = 'globalhistory'
