default_app_config = 'wiki.plugins.help.apps.HelpConfig'
