default_app_config = 'wiki.plugins.redlinks.apps.RedlinksConfig'
