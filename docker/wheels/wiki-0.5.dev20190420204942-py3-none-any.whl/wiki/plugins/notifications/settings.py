
# Deprecated
APP_LABEL = None

# Key for django_nyt - changing it will break any existing notifications.
ARTICLE_EDIT = "article_edit"

SLUG = 'notifications'
