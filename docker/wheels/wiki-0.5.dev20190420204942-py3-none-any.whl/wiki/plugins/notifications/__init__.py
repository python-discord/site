default_app_config = 'wiki.plugins.notifications.apps.NotificationsConfig'
