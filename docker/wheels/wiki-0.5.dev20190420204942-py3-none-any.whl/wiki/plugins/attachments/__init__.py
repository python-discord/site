default_app_config = 'wiki.plugins.attachments.apps.AttachmentsConfig'
