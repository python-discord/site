default_app_config = 'wiki.plugins.macros.apps.MacrosConfig'
