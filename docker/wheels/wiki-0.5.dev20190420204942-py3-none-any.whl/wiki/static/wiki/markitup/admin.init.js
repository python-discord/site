jQuery = django.jQuery;


django.jQuery(document).ready(function() {
   django.jQuery(".markItUp").markItUp(mySettings);
});
