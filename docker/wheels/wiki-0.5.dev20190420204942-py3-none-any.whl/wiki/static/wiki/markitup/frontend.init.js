$(document).ready(function() {
   $(".markItUp").markItUp(mySettings);
});
