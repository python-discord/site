$(document).ready(function() {

  $('.wiki-article .article-list ul, .wiki-article .toc ul').each(function() {
    $(this).addClass('nav');
    $(this).addClass('nav-list');
  });

});
